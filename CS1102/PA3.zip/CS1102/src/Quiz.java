import javax.swing.JOptionPane;

public class Quiz {
    static int nQuestions = 0;
    static int nCorrect = 0;

    public static void main(String[] args) {
        check ("What is the best programming language?\n"
                + "A. Of course Java\n"
                +"B. Golang is cutting-edge\n"
                + "C. Python is nice for beginners\n"
                + "D. C is classic and cool\n"
                + "E. I love PHP though\n",
                "A");
        check ("Who is the best MLB baseball player in this season?\n"
                + "A. Tatis Jr.\n"
                +"B. Guerrero Jr.\n"
                + "C. Shohei Ohtani\n"
                + "D. Acuna Jr.\n"
                + "E. Jacob deGrom\n",
                "C");
        check ("In what city, Olympic game will be held in 2021?\n"
                + "A. London\n"
                +"B. Barcelona\n"
                + "C. Berlin\n"
                + "D. Tokyo\n"
                + "E. Melbourne\n",
                "D");
        JOptionPane.showMessageDialog(null, nCorrect + " correct out of " + nQuestions+ " questions.");

        }
    public static String ask (String question) {
        while(true){

            String answer = JOptionPane.showInputDialog(question);
            answer = answer.toUpperCase();
            if(!((answer.equals("A"))||(answer.equals("B")) ||(answer.equals("C")) ||(answer.equals("D"))||(answer.equals("E")))){
                JOptionPane.showMessageDialog(null, "Invalid answer. Please enter A, B, C, D, or E.");
            }
            else {
                return answer;
            }
        }
    }
    public static void check (String question, String correctAnswer) {

        String answer = ask(question);
        if (answer.equals(correctAnswer)) {
            JOptionPane.showMessageDialog(null, "You are correct!");
            nCorrect ++;
        }else {
            JOptionPane.showMessageDialog(null, "Incorrect. The correct answer is " + correctAnswer + ".");
        }
        nQuestions ++;
    }
}