public class Quiz {
    public static void main(String[] args) {
        MultipleChoiceQuestion question1 = new MultipleChoiceQuestion("What is the best programming language?"
                ,"A. Of course Java"
                ,"B. Golang is cutting-edge"
                ,"C. Python is nice for beginners"
                ,"D. C is classic and cool"
                ,"E. I love PHP though"
                ,"a");

        MultipleChoiceQuestion question2 = new MultipleChoiceQuestion("Who is the best MLB baseball player in this season?"
                ,"A. Tatis Jr."
                ,"B. Guerrero Jr."
                ,"C. Shohei Ohtani"
                ,"D. Acuna Jr."
                ,"E. Jacob deGrom"
                ,"c");

        MultipleChoiceQuestion question3 = new MultipleChoiceQuestion("In what city, Olympic game will be held in 2021?"
                ,"A. London"
                ,"B. Barcelona"
                ,"C. Berlin"
                ,"D. Tokyo"
                ,"E. Melbourne"
                ,"d");

        MultipleChoiceQuestion question4 = new MultipleChoiceQuestion("Which country won a title of EURO2021?"
                ,"A. England"
                ,"B. France"
                ,"C. Sweden"
                ,"D. Denmark"
                ,"E. Italy"
                ,"e");

        MultipleChoiceQuestion question5 = new MultipleChoiceQuestion("Which company are not included in GAFA?"
                ,"A. Google"
                ,"B. Amazon"
                ,"C. Apple"
                ,"D. Alibaba"
                ,"E. Facebook"
                ,"d");

        question1.check();
        question2.check();
        question3.check();
        question4.check();
        question5.check();

        MultipleChoiceQuestion.showResults();
        }
}