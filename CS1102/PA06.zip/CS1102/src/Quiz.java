public class Quiz {
    public static void main(String[] args) {
        Question question1 = new MultipleChoiceQuestion("What is the best programming language?"
                ,"A. Of course Java"
                ,"B. Golang is cutting-edge"
                ,"C. Python is nice for beginners"
                ,"D. C is classic and cool"
                ,"E. I love PHP though"
                ,"a");

        Question question2 = new MultipleChoiceQuestion("Who is the best MLB baseball player in this season?"
                ,"A. Tatis Jr."
                ,"B. Guerrero Jr."
                ,"C. Shohei Ohtani"
                ,"D. Acuna Jr."
                ,"E. Jacob deGrom"
                ,"c");

        Question question3 = new MultipleChoiceQuestion("In what city, Olympic game will be held in 2021?"
                ,"A. London"
                ,"B. Barcelona"
                ,"C. Berlin"
                ,"D. Tokyo"
                ,"E. Melbourne"
                ,"d");

        Question question4 = new MultipleChoiceQuestion("Which country won a title of EURO2021?"
                ,"A. England"
                ,"B. France"
                ,"C. Sweden"
                ,"D. Denmark"
                ,"E. Italy"
                ,"e");

        Question question5 = new MultipleChoiceQuestion("Which company are not included in GAFA?"
                ,"A. Google"
                ,"B. Amazon"
                ,"C. Apple"
                ,"D. Alibaba"
                ,"E. Facebook"
                ,"d");

        question1.check();
        question2.check();
        question3.check();
        question4.check();
        question5.check();

        Question question6 = new TrueFalseQuestion("AWS stands for Amazon Web Site", "FALSE");
        Question question7 = new TrueFalseQuestion("GCP stands for Google Cloud Platform", "TRUE");
        Question question8 = new TrueFalseQuestion("JavaScript inherits many features of Java", "FALSE");
        Question question9 = new TrueFalseQuestion("In Java, class fields can have not only variable but also method", "TRUE");
        Question question10 = new TrueFalseQuestion("Population of Japan is rapidly declining and aging", "TRUE");


        question6.check();
        question7.check();
        question8.check();
        question9.check();
        question10.check();

        Question.showResults();
        }
}