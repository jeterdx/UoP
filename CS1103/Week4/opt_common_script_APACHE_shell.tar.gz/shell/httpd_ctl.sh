#!/bin/sh
#
#######################################################################
# Copyright (C) 2009 Recruit Co.,Ltd.  All rights reserved
# SystemName       ：Grand Line Project(RAFTEL)
# FunctionName     ：Apache Control Script
# FunctionSummary  ：Control Apache Instance
# Argument         ：start|stop|restart|graceful|graceful-stop|configtest
# ExitStatus       ：0=normal　/ not 0=error
# History          ：
#   NO Date Ver Person Contents
#   1 2009/03/18 v1.00 NSSOL) New Create
#   2 2009/05/29 v1.10 NSSOL) Include setenv.sh
#######################################################################

#env
SITE=$1
INST=$2
APC_VER=$3
APC_BIN=/usr/local/apache/${APC_VER}
SERVER_ROOT=/app/${SITE}/${INST}/apache
APACHE_CONF=/app/${SITE}/${INST}/apache/conf/httpd_${SITE}_${INST}.conf
ACTION=$4

#check
if [ $# -lt 4 ]; then
       echo "Usage: $0 SITE INSTANCE APACHE_VERSION ACTION(start|stop|restart|graceful|graceful-stop|configtest)"
       exit 1
fi
if [ ! -d ${APC_BIN} ]; then
       echo "Directory Not Found [${APC_BIN}]"
       exit 1
fi
if [ ! -f ${APACHE_CONF} ]; then
       echo "ApacheConfig Not Found [${APACHE_CONF}]"
       exit 1
fi

#include setenv.sh
if [ -r ${SERVER_ROOT}/bin/setenv.sh ]; then
       . ${SERVER_ROOT}/bin/setenv.sh
fi

#exec
case $ACTION in

'start' | 'stop' | 'restart' | 'graceful' | 'graceful-stop' )

       echo "${APC_BIN}/bin/apachectl -d $SERVER_ROOT -f $APACHE_CONF -k $ACTION -DSSL"
       ${APC_BIN}/bin/apachectl -d $SERVER_ROOT -f $APACHE_CONF -k $ACTION -DSSL
       RET=$?
       ;;
'configtest' )
       echo "${APC_BIN}/bin/apachectl -t -f $APACHE_CONF"
       ${APC_BIN}/bin/apachectl -t -f $APACHE_CONF
       RET=$?
       ;;
*)
       echo "Usage: $0 start|stop|restart|graceful|graceful-stop|configtest"
       RET=1
esac

exit $RET
