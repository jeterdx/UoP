#!/bin/sh
#
#######################################################################
# Copyright (C) 2009 Recruit Co.,Ltd.  All rights reserved
# SystemName       ：Grand Line Project(RAFTEL)
# FunctionName     ：Apache Control Script
# FunctionSummary  ：Stop Apache Instance
# Argument         ：no
# ExitStatus       ：0=normal　/ not 0=error
# History          ：
#   NO Date Ver Person Contents
#   1 2009/03/18 v1.00 NSSOL) New Create
#   2 2009/05/29 v1.10 NSSOL) Include setenv.sh
#######################################################################

#env
SITE=$1
INST=$2
APC_VER=$3
APC_BIN=/usr/local/apache/${APC_VER}
SERVER_ROOT=/app/${SITE}/${INST}/apache
APACHE_CONF=/app/${SITE}/${INST}/apache/conf/httpd_${SITE}_${INST}.conf

#check
if [ $# -lt 3 ]; then
       echo Usage: $0 SITE INSTANCE APACHE_VERSION
       exit 1
fi
if [ ! -d ${APC_BIN} ]; then
       echo "Directory Not Found [${APC_BIN}]"
       exit 1
fi
if [ ! -f ${APACHE_CONF} ]; then
       echo "ApacheConfig Not Found [${APACHE_CONF}]"
       exit 1
fi

#include setenv.sh
if [ -r ${SERVER_ROOT}/bin/setenv.sh ]; then
       . ${SERVER_ROOT}/bin/setenv.sh
fi

#exec
echo "${APC_BIN}/bin/apachectl -d $SERVER_ROOT -f $APACHE_CONF -k stop"
${APC_BIN}/bin/apachectl -d $SERVER_ROOT -f $APACHE_CONF -k stop
RET=$?

sleep 3

exit $RET
